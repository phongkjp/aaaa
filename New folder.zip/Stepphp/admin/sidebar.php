<nav class="navbar-default navbar-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">

            <li>
                <a class="active-menu" href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a>
            </li>
            <li>
                <a href="blog_categories.php"><i class="fa fa-desktop"></i> Blog Categories</a>
            </li>
            <li>
                <a href="blogs.php"><i class="fa fa-bar-chart-o"></i> Blogs</a>
            </li>
            <li>
                <a href="write_a_blog.php"><i class="fa fa-qrcode"></i> Write Blog</a>
            </li>
            
            <li>
                <a href="blog_contact.php"><i class="fa fa-table"></i> Blog Contact</a>
            </li>
            <li>
                <a href="blog_subscribers.php"><i class="fa fa-edit"></i> Blog Subscribers</a>
            </li>

        </ul>

    </div>

</nav>
